<?php
/**
 * Template Name: Template - Latest Posts
 */
?>
<?php get_header(); ?>

<?php get_template_part('frontloop'); // frontloop.php ?>

<?php wp_reset_postdata(); ?>
<?php get_footer(); ?>
