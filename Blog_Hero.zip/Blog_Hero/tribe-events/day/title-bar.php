<article class="tribe-events-title-bar">
	<!-- Page header __-->
	<div class="entry-header">
		<h2><?php echo tribe_get_events_title() ?></h2>
	</div>
</article>