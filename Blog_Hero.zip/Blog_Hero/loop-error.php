</div>
<article>
	<div class="entry-content loop-error">
		
		<?php if( is_404() ): ?>	
		
		<h1><a class="mega404"><?php esc_html_e( '404', 'dk_insider' ); ?></a></h1>
		<h2><?php esc_html_e( 'Oops!... Algo de certo esta errado ! ', 'dk_insider' ); ?></h2>
		<p><?php esc_html_e( 'Não conseguimos encontrar a sua pagina..', 'dk_insider' ); ?></p>
		<p><a href="#" onclick="window.history.go(-1)" class="button">&larr; <?php esc_html_e( 'Voltar á última página', 'dk_insider' ); ?></a></p>
	
	
		<?php else: ?>

		<h2><?php esc_html_e( 'Nada encontrado', 'dk_insider' ); ?></h2>
		<p><?php esc_html_e( 'Desculpa. Não foi encontrado nada com essa palavra chave. Procure com outras palavras.', 'dk_insider' ); ?></p>
		<?php get_search_form(); ?>
		<p><a href="#" onclick="window.history.go(-1)" class="button">&larr;  <?php esc_html_e( 'Voltar á última página', 'dk_insider' ); ?></a></p>
		
		<?php endif; ?>
	</div>
</article>