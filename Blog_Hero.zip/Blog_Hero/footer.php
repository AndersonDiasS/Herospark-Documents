		
		</div><!-- .wrapper -->
	</main>
	
	
	<!-- ====================
	       FOOTER 
	==================== -->
	<footer id="footer">
		<ul class="social-icons">
			<?php get_template_part('social_icons-list'); ?>
		</ul>
		
		<?php get_sidebar( 'footer' ); ?>
		
		<div class="bottom">
		
				<p><?php echo esc_attr( get_theme_mod( 'insider_footer_text' )); ?></p>
				<nav id="menu">
					<?php get_template_part( 'menu', 'primary' ); // menu-primary.php ?>
				</nav>
	
		</div>
	</footer>
</div><!-- #wrapperbox -->

<?php wp_footer(); ?>
</body>
</html>